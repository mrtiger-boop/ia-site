# Siteo

Siteo est un générateur de sites web avec IA.

## Inclus

- Logo Siteo propre
- Interface professionnelle
- Supabase Auth
- Vérification email
- Crédits stockés dans Supabase
- 100 crédits gratuits
- 10 crédits par génération
- Stripe Pro
- Téléchargement ZIP
- OpenRouter
- Compatible Render

## Structure

```txt
siteo-pro-complet/
├── public/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── server.js
├── package.json
├── README.md
└── .env.example
```

## Installation

```bash
npm install
npm start
```

Puis ouvre :

```txt
http://localhost:3000
```

## Supabase

Le front utilise :

```txt
https://azgahpygwlrrmozbjrqo.supabase.co
```

Vérifie que ta table `profiles` existe :

```sql
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text,
  email text unique,
  plan text default 'free',
  credits integer default 100,
  created_at timestamptz default now()
);
```

## Variables d'environnement

En local, crée `.env` :

```env
OPENROUTER_API_KEY=ta_cle_openrouter
PUBLIC_SITE_URL=http://localhost:3000
```

Sur Render, ajoute ces variables dans Environment.
